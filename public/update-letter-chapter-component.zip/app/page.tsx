'use client'

import { LetterChapter } from '@/components/letter-chapter'

export default function Page() {
  const sampleLetter = `Just for You

Some words are just meant to be read slowly, with a smile on your face and love in your heart.`

  return (
    <main className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-rose-50">
      <LetterChapter letter={sampleLetter} />
    </main>
  )
}
